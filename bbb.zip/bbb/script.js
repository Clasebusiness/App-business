document.getElementById('start-button').addEventListener('click', function() {
    // Ocultar la pantalla de bienvenida
    document.getElementById('welcome-screen').style.display = 'none';

    // Mostrar la pantalla de inicio de sesión
    document.getElementById('login-screen').style.display = 'flex';
});

document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Iniciando sesión con correo y contraseña...');
    // Aquí agregarías la lógica para iniciar sesión con correo y contraseña
});

document.querySelector('.google-button').addEventListener('click', function() {
    alert('Iniciando sesión con Google...');
    // Aquí agregarías la lógica para iniciar sesión con Google
});

